This folder contains the files for Assignment 1 submission including the Assignment 1 question paper, the codes and the data and plot generated from code and finally the .pdf file that contains the answers for the questions in the assignment

The folder src contains the source code and the data generated with the given test cases in the assignment questions. All codes have to be run individually to obtain the data.

The folder Result_Images_and_Docs contains the plots and the .pdf file 

The code for all the algorithm was developed in C++ and the code for plotting was developed in python

The .pdf was generated using latex ,the source code .tex file is also included.