Some of the csv files are too big, hence I am not adding them in the submission. To check the result, kindly run the code from the provided folder to obtain the results in the solution folder. 

Thank You